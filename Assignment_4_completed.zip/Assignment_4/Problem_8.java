// 8	Write a program to merge two sorted linked lists into one sorted linked list. **


class MyLinkedList{
    Node head;


    class Node{
        int data;
        Node next;
    
        Node(int data){
            this.data =data;
            next = null;
        }
    }


    public  int addData(int data){

        if(head == null){
            Node newNode = new Node(data);
            head = newNode;
        }
        else {
            Node temp = head;
            while (temp.next != null){
                temp = temp.next;
            }
            Node newNode = new Node(data);
            temp.next = newNode;
        }
      return data;
    }

    


    public void printList(){

        if (head == null) {
            System.out.println("list is empty");
            return;
        }
        else if (head.next == null){
            System.out.println(head.data);
            return;
        }

        System.out.println();
       
        Node temp = head;

        while (temp.next != null){
            System.out.print(temp.data+" -> ");
            temp = temp.next;
        }
        System.out.print(temp.data+" -> ");
        System.out.println();
    }


    public void reverseListIterative(){

        if(head == null){
            System.out.println("List is empty");
        }

        Node peviousNode = head;
        Node currentNode = head.next;
        while (currentNode != null) {
            Node newNode = currentNode.next;

            currentNode.next = peviousNode;

            peviousNode = currentNode;
            currentNode = newNode;
        }

        head.next = null;
        head = peviousNode;
        System.out.println("List reversed");

    }


    public void reverseRescurive(Node peviousNode,Node currentNode,Node nextNode){

        if(currentNode == null){
            head.next = null;
            head = peviousNode;
            return;
        }

               nextNode = currentNode.next;

            currentNode.next = peviousNode;

            peviousNode = currentNode;
            currentNode = nextNode;

            reverseRescurive(peviousNode, currentNode, nextNode);
    }



    public void reverseListRecursive(){

        if(head == null){
            System.out.println("List is empty");
            return;
        }

        Node peviousNode = head;
        Node currentNode = head.next;
        Node nextNode = null;

        reverseRescurive(peviousNode,currentNode,nextNode);

    }



    Node  merge(Node head1, Node head2) {
        
        Node sortedList = new Node(-1);
        Node sortedNode = sortedList;
        
        
        Node temp1 = head1;
        Node temp2 = head2;
        
        while(temp1 != null && temp2 != null){
            
            if(temp1.data < temp2.data){
                
                sortedNode.next = temp1;
                temp1 = temp1.next;

            }
            else{
                sortedNode.next = temp2;
                temp2 = temp2.next;
            }
            
            sortedNode = sortedNode.next;
            
        }
        
         if(temp1 != null) {
            sortedNode.next = temp1;
             }
        
        if(temp2 != null) {
            sortedNode.next = temp2;
        } 
        
        return sortedList.next;
    }



    public  void MergeLists(MyLinkedList list1, MyLinkedList list2){


        Node head = merge(list1.head, list2.head);

        if (head == null) {
            System.out.println("list is empty");
            return;
        }
        else if (head.next == null){
            System.out.println(head.data);
            return;
        }

        System.out.println();
       
        Node temp = head;

        while (temp.next != null){
            System.out.print(temp.data+" -> ");
            temp = temp.next;
        }
        
        System.out.print(temp.data+" -> ");
        System.out.println();

    }



}

public class Problem_8 {

    public static void main(String[] args) {
        

        MyLinkedList list1 = new MyLinkedList();
        list1.addData(5);
        list1.addData(10);
        list1.addData(15);
        list1.addData(40);


        MyLinkedList list2 = new MyLinkedList();
        list2.addData(2);
        list2.addData(3);
        list2.addData(20);

        list1.MergeLists(list1, list2);

    }
}