// Write a program to find the middle element of a singly linked list in one pass (using the fast and slow pointer approach).  **

 class MyLinkedList{
    Node head;


    class Node{
        int data;
        Node next;
    
        Node(int data){
            this.data =data;
            next = null;
        }
    }


    public  int addData(int data){

        if(head == null){
            Node newNode = new Node(data);
            head = newNode;
        }
        else {
            Node temp = head;
            while (temp.next != null){
                temp = temp.next;
            }
            Node newNode = new Node(data);
            temp.next = newNode;
        }
      return data;
    }

    


    public void printList(){

        if (head == null) {
            System.out.println("list is empty");
            return;
        }
        else if (head.next == null){
            System.out.println(head.data);
            return;
        }

        System.out.println();
       
        Node temp = head;

        while (temp.next != null){
            System.out.print(temp.data+" -> ");
            temp = temp.next;
        }
        System.out.print(temp.data+" -> ");
        System.out.println();
    }


    public void reverseListIterative(){

        if(head == null){
            System.out.println("List is empty");
        }

        Node peviousNode = head;
        Node currentNode = head.next;
        while (currentNode != null) {
            Node newNode = currentNode.next;

            currentNode.next = peviousNode;

            peviousNode = currentNode;
            currentNode = newNode;
        }

        head.next = null;
        head = peviousNode;
        System.out.println("List reversed");

    }


    public void reverseRescurive(Node peviousNode,Node currentNode,Node nextNode){

        if(currentNode == null){
            head.next = null;
            head = peviousNode;
            return;
        }

               nextNode = currentNode.next;

            currentNode.next = peviousNode;

            peviousNode = currentNode;
            currentNode = nextNode;

            reverseRescurive(peviousNode, currentNode, nextNode);
    }

    public void reverseListRecursive(){

        if(head == null){
            System.out.println("List is empty");
            return;
        }

        Node peviousNode = head;
        Node currentNode = head.next;
        Node nextNode = null;

        reverseRescurive(peviousNode,currentNode,nextNode);

    }


    public int getMiddle(){

        if(head == null){
            System.out.println("List is empty");
            return -1;
        }

        Node slow = head;
        Node fast = head;

        while (fast != null && fast.next != null) {
            fast = fast.next.next;
            slow = slow.next;
        }

        return slow.data;
    }


}

public class Problem_5 {

    public static void main(String[] args) {

        MyLinkedList myLinkedList = new MyLinkedList();

        myLinkedList.addData(10);
        myLinkedList.addData(20);
        myLinkedList.addData(30);
        myLinkedList.addData(40);
        myLinkedList.addData(50);
        myLinkedList.addData(800);
       myLinkedList.addData(500);


        int middle = myLinkedList.getMiddle();

        System.out.println("Middle of the list is :"+middle);
      

    }
}