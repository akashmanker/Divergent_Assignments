// 7	Implement Dijkstra’s algorithm for finding the shortest path in a graph represented using adjacency lists.

import java.util.ArrayList;
import java.util.PriorityQueue;
import java.util.Queue;


public class Problem_7 {

    static class Edge {
        private int src;
        private int des;
        private int wtq;

        public Edge(int src, int des, int wtq) {
            this.src = src;
            this.des = des;
            this.wtq = wtq;
        }

        public int getSrc() {
            return src;
        }

        public int getDes() {
            return des;
        }

        public int getWtq() {
            return wtq;
        }
    }

    static class Pair implements Comparable<Pair> {

        private int node;

        private int path;

        public Pair(int node, int path) {

            this.node = node;

            this.path = path;
        }

        @Override
        public int compareTo(Pair other) {
            return Integer.compare(this.path, other.path);
        }
    }

    public static void dijkstraAlgo(ArrayList<Edge>[] graph, int src) {
        
        int[] dis = new int[graph.length];
        
        boolean[] visited = new boolean[graph.length];

        for (int i = 0; i < graph.length; i++) {
            dis[i] = (i != src) ? Integer.MAX_VALUE : 0;
        }

        Queue<Pair> queue = new PriorityQueue<>();
        
        queue.add(new Pair(src, 0));

        while (!queue.isEmpty()) {
          
            Pair curr = queue.remove();

            if (!visited[curr.node]) {
               
                visited[curr.node] = true;

                for (Edge edge : graph[curr.node]) {
                    int u = edge.getSrc();
                   
                    int v = edge.getDes();
                    
                    int wtq = edge.getWtq();

                    if (dis[u] + wtq < dis[v]) {
                       
                        dis[v] = dis[u] + wtq;
                       
                        queue.add(new Pair(v, dis[v]));
                    }
                }
            }
        }

        for (int ele : dis) {
            
            System.out.print(ele + " ");
        }
       
        System.out.println();
    }

    public static void main(String[] args) {
        
        int vertex = 6;
       
        ArrayList<Edge>[] graph = new ArrayList[vertex];

        for (int i = 0; i < vertex; i++) {
            graph[i] = new ArrayList<>();
        }

        graph[0].add(new Edge(0, 1, 2));
        graph[0].add(new Edge(0, 2, 4));
        graph[1].add(new Edge(1, 2, 1));
        graph[1].add(new Edge(1, 3, 7));
        graph[2].add(new Edge(2, 4, 3));
        graph[3].add(new Edge(3, 5, 1));
        graph[4].add(new Edge(4, 3, 2));
        graph[4].add(new Edge(4, 5, 5));
        graph[5].add(new Edge(5, 0, 8));

        dijkstraAlgo(graph, 0);
    }
}
