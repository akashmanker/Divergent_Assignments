    // 3	Write a program to implement a queue using two stacks.

class MyStack1 {

    int size;
    int arr[];
    int top;

    MyStack1(int size){
        arr = new int[size];
        top = -1;
    }



    public int push(int data){

        if(top >= arr.length-1){
            System.out.println("Stack overflow");
            return -1;
        }

        top = top+1;
        arr[top] = data;
        return arr[top];
    }



    public int pop(){

        if(top == -1){
            System.out.println("Stack Underflow");
            return -1;
        }

       int removed =  arr[top];
       arr[top] = -1;
        top = top - 1;

        return removed;
    }


    public int peek(){

        if(top == -1){
            System.out.println("Stack Underflow");
            return -1;
        }

        return arr[top];
    }


    public boolean isEmpty(){

        if(top == -1){
            return true;}

            else return false;
    }

    public boolean isFull(){

       if(top == arr.length-1)  return true;

            else return false;
    }



    
}

class MyQueue{

    MyStack stack1;
    MyStack stack2;

    public MyQueue(int size) {

        stack1 = new MyStack(size);
        stack2 = new MyStack(size);
    }

    public void enqueue(int data) {

        while (!stack1.isEmpty()) {
            stack2.push(stack1.pop());
        }

        stack1.push(data);

        while (!stack2.isEmpty()) {
            stack1.push(stack2.pop());
        }

    }

    public int dequeue() {
        if (stack1.isEmpty()) {
            System.out.println("Queue is Empty");
            return -1;
        }
        return stack1.pop();
    }


    public int peek(){

       return stack1.peek();
    }

}



public class Problem_3 {

    public static void main(String[] args) {


        MyQueue queue = new MyQueue(3);

        queue.enqueue(20);

        queue.enqueue(40);
        queue.enqueue(50);
        // queue.enqueue(99);                       overflow condition

        System.out.println(queue.dequeue());        //20
        System.out.println(queue.dequeue());      //40
       // System.out.println(queue.dequeue());  

        System.out.println(queue.peek());          //50

        // System.out.println(queue.dequeue());    underflow condition


        
        
    }


}
