import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Scanner;

// Write a program to find duplicates in an array where the numbers are within a fixed range (e.g., 1 to n). Use a data structure like a HashSet or modify the array in-place.

public class Problem_9 {

    public static void findDuplicatesUsingList(int arr[]){

        ArrayList<Integer> list = new ArrayList<>();
        HashSet<Integer> set = new HashSet<>();

        for(int i=0;i<arr.length;i++){

            if(list.contains(arr[i])){
                set.add(arr[i]);
            }
            else{
                list.add(arr[i]);
            }
    }
    
    System.out.println("duplicate elements in list :"+set);
    System.out.println("after removing duplicates list :"+list);
}
    


    public static void findDuplicatesWithoutList(int arr[]){

        int tempArray[] = new int[arr.length];

        for (int i = 0; i < arr.length; i++) {

            if (tempArray[arr[i] - 1] == 0) { 
                tempArray[arr[i] - 1] = -1;    
            }  
          else {
                System.out.println("Duplicate found: " + arr[i]);
            }
        }
    }


    public static void main(String[] args) {        
      

        int arr[] = {2, 1 ,1, 3, 4, 4};

        findDuplicatesUsingList(arr);       // using a HashSet

        findDuplicatesWithoutList(arr);       // without using a hashSet

    }
    
}
