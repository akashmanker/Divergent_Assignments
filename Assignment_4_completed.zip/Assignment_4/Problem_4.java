// Write a program to implement a binary search tree with operations like insert, delete, search, and in-order traversal.(Binary Search Tree (BST))

 class MyBinarySearchTree{

    Node root;

     public class Node {
        
        int data;
        Node left;
        Node right;

        public Node(int data){
            this.data = data;
            left = null;
            right = null;
        }
        
    }

    public void insert(int data) {

        if (root == null) {
            Node newNode = new Node(data);
            root = newNode;
        } 
        else 
        {
            Node temp = root;
    
            while (true) { 

                if (data < temp.data) {

                    if (temp.left == null) {

                        Node newNode = new Node(data);
                        temp.left = newNode;
                        return;

                    }
                     else
                      {
                        temp = temp.left;  
                      }
                } 
                else if (data > temp.data){

                    if (temp.right == null) {
                        Node newNode = new Node(data);
                        temp.right = newNode;
                        return;
                    } 
                    else
                     {
                        temp = temp.right;  
                    }
                } 
                
            }
        }
    }



    public boolean search(int key) {

        if (root == null) {
            System.out.println("Tree is empty");
            return false;
        }
    
        Node temp = root;
    
        while (temp != null) {

            if (key == temp.data) {

                return true; 

            }          
           else if (key < temp.data) {
                temp = temp.left; 
            } 
            else {
                temp = temp.right; 
            }
        }

            return false;
    }


    public void inorder(Node temp) {        //recurssive method
        if (temp != null) {
            inorder(temp.left);
            System.out.print(temp.data + " ");
            inorder(temp.right);
        }
    }


    public void inorderTraverse(){    //caller   method
        inorder(root);
    }



    public void deleteLeafNode(int key) {
        root = deleteLeaf(root, key);
    }

    Node deleteLeaf(Node root, int key) {

        Node parent = null;
        Node current = root;

        while (current != null && current.data != key) {

            parent = current;
            if (key < current.data) {
                current = current.left;
            } 
            else {
                current = current.right;
            }
        }

        if (current == null) {
            System.out.println("Key not found");
            return root;
        }

        if (current.left == null && current.right == null) {

            if (current != root) {

                if (parent.left == current) {

                    parent.left = null;
                } 
                else {
                    parent.right = null;
                }
            }
            else {
                root = null; 
            }
        } 
        else {
            System.out.println("The node is not a leaf node.");
        }


        return root;
    }


 }
public class Problem_4{


    public static void main(String[] args) {

        MyBinarySearchTree tree = new MyBinarySearchTree();

        tree.insert(1);

        tree.insert(2);

        tree.insert(3);

        tree.insert(4);

        tree.insert(5);

        System.out.println(tree.search(3));  // true


        tree.inorderTraverse();     // 1,2,3,4,5

        tree.deleteLeafNode(5);

        System.out.println();

        tree.inorderTraverse();        // 1,2,3,4
    }
}