
// 1 Write a program to reverse a singly linked list. Implement both iterative and recursive approaches.


class MyLinkedList{
    Node head;


    class Node{
        int data;
        Node next;
    
        Node(int data){
            this.data =data;
            next = null;
        }
    }


    public  int addData(int data){

        if(head == null){
            Node newNode = new Node(data);
            head = newNode;
        }
        else {
            Node temp = head;
            while (temp.next != null){
                temp = temp.next;
            }
            Node newNode = new Node(data);
            temp.next = newNode;
        }
      return data;
    }

    


    public void printList(){

        if (head == null) {
            System.out.println("list is empty");
            return;
        }
        else if (head.next == null){
            System.out.println(head.data);
            return;
        }

        System.out.println();
       
        Node temp = head;

        while (temp.next != null){
            System.out.print(temp.data+" -> ");
            temp = temp.next;
        }
        System.out.print(temp.data+" -> ");
        System.out.println();
    }


    public void reverseListIterative(){

        if(head == null){
            System.out.println("List is empty");
        }

        Node peviousNode = head;
        Node currentNode = head.next;
        while (currentNode != null) {
            Node newNode = currentNode.next;

            currentNode.next = peviousNode;

            peviousNode = currentNode;
            currentNode = newNode;
        }

        head.next = null;
        head = peviousNode;
        System.out.println("List reversed");

    }


    public void reverseRescurive(Node peviousNode,Node currentNode,Node nextNode){

        if(currentNode == null){
            head.next = null;
            head = peviousNode;
            return;
        }

               nextNode = currentNode.next;

            currentNode.next = peviousNode;

            peviousNode = currentNode;
            currentNode = nextNode;

            reverseRescurive(peviousNode, currentNode, nextNode);
    }

    public void reverseListRecursive(){

        if(head == null){
            System.out.println("List is empty");
            return;
        }

        Node peviousNode = head;
        Node currentNode = head.next;
        Node nextNode = null;

        reverseRescurive(peviousNode,currentNode,nextNode);

    }




}

public class Problem_1 {


    public static void main(String[] args) {
        
        MyLinkedList list = new MyLinkedList();
        list.addData(12);
        list.addData(15);
        list.addData(30);
        list.addData(55);
        list.printList();

        System.out.println();
        list.reverseListIterative();       // iterative


        list.printList();

        System.out.println("Adding more data ");
        list.addData(100);
        list.addData(200);

        list.printList();
        

        list.reverseListRecursive();   //reversed

        list.printList();

        list.reverseListRecursive();   // recursive

        list.printList();

        list.addData(1000);

        list.printList();
        
    }


}
