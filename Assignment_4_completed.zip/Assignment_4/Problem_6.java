// 6  Write a program to check if a string of parentheses (e.g., {}, [], ()) is balanced using a stack. **


import java.util.*;

public class Problem_6 {


    public static boolean checkBalance(String str){

    if(str.length()<=1 || str.length() % 2 != 0){
        return false;
    }

    Stack<Character> stack = new Stack<>();
    
    for(int i=0;i<str.length();i++){
        
        if(str.charAt(i)=='[' || str.charAt(i)=='{' || str.charAt(i)=='('){
            stack.push(str.charAt(i));
        }
        else if(stack.empty()){
            return false;
        }
        else{

            if(str.charAt(i)==')'){
                if(stack.pop()!='('){
                    return false;
                }
            }

            if(str.charAt(i)=='}'){
                if(stack.pop()!='{'){
                    return false;
                }
            }

            if(str.charAt(i)==']'){
                if(stack.pop()!='['){
                    return false;
                }
            }
        }
    }


    if(stack.isEmpty()){
    return true;
    }
    return false;
}



    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
       
        System.out.println("Enter the string");
        
        String str = sc.nextLine();

        boolean result =   checkBalance(str);
        System.out.println(result);
        
    }


}
