
import java.util.HashMap;

class MyLRUCache {
    
    private class Node {
        int key, value;
        Node prev, next;

        Node(int key, int value) {
            this.key = key;
            this.value = value;
        }
    }

    private final int capacity;

    private HashMap<Integer, Node> cache;

    private Node head, tail;

    public MyLRUCache(int capacity) {
       
        this.capacity = capacity;
        this.cache = new HashMap<>();
        
        head = new Node(0, 0);

        tail = new Node(0, 0);

        head.next = tail;

        tail.prev = head;
    }

    public int get(int key) {
        if (!cache.containsKey(key)) {
            return -1;  
        }

        Node node = cache.get(key);
        moveToHead(node);
        return node.value;
    }

    public void put(int key, int value) {
        if (cache.containsKey(key)) {

            Node node = cache.get(key);

            node.value = value;

            moveToHead(node);
        } 
        else{

            Node newNode = new Node(key, value);

            cache.put(key, newNode);

            addNode(newNode);
            
            if (cache.size() > capacity) {
                Node tailNode = popTail();
                cache.remove(tailNode.key);
            }
        }
    }

    private void addNode(Node node) {
        node.prev = head;
        node.next = head.next;
        head.next.prev = node;
        head.next = node;
    }

    private void removeNode(Node node) {
        Node prev = node.prev;
        Node next = node.next;

        prev.next = next;
        next.prev = prev;
    }

    private void moveToHead(Node node) {
        removeNode(node);
        addNode(node);
    }

    private Node popTail() {
        Node res = tail.prev;
        removeNode(res);
        return res;
    }

    public void displayCache() {
        Node current = head.next;
        System.out.print("Cache state: ");
        while (current != tail) {
            System.out.print("[" + current.key + "=" + current.value + "] ");
            current = current.next;
        }
        System.out.println();
    }
}


public class Problem_10 {

    public static void main(String[] args) {

        MyLRUCache ml = new MyLRUCache(3);

        ml.put(1, 10);  
        ml.put(2, 20);  
        ml.put(3, 30);  

        System.out.println("Value for key 2 is" + ml.get(2)); 
        
        ml.displayCache();  

        ml.put(4, 40); 

        System.out.println("Value for key 1 is " + ml.get(1)); 
        
        ml.displayCache();  
        
    }
}
