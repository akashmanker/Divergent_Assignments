// 2	Write a program to implement a stack using an array and perform operations like push, pop, peek, and isEmpty.

import java.util.Arrays;

class MyStack {

    int size;
    int arr[];
    int top;

    MyStack(int size){
        arr = new int[size];
        top = -1;
    }



    public int push(int data){

        if(top >= arr.length-1){
            System.out.println("Stack overflow");
            return -1;
        }

        top = top+1;
        arr[top] = data;
        return arr[top];
    }



    public int pop(){

        if(top == -1){
            System.out.println("Stack Underflow");
            return -1;
        }

       int removed =  arr[top];
       arr[top] = -1;
        top = top - 1;

        return removed;
    }


    public int peek(){

        if(top == -1){
            System.out.println("Stack Underflow");
            return -1;
        }

        return arr[top];
    }


    public boolean isEmpty(){

        if(top == -1){
            return true;}

            else return false;
    }

    public boolean isFull(){

       if(top == arr.length-1)  return true;

            else return false;
    }


    @Override
    public String toString() {
        return "MyStack [size=" + size + ", arr=" + Arrays.toString(arr) + ", top=" + top + "]";
    }
    
}

public class Problem_2 {

    public static void main(String[] args) {
        
        MyStack myStack = new MyStack(5);

        System.out.println(myStack.isEmpty());

        myStack.push(20);
        myStack.push(40);
        myStack.push(60);
        myStack.push(80);
        myStack.push(100);
      //  myStack.push(120);        give overflow

        System.out.println( myStack.peek());    //100

       System.out.println(myStack.pop());   //100

       System.out.println( myStack.peek());    //80
       System.out.println(myStack.pop());      //80
       System.out.println( myStack.peek());     //60

    //    System.out.println(myStack.pop());
    //    System.out.println(myStack.pop());
    //    System.out.println(myStack.pop());
    //    System.out.println(myStack.pop());  //give Underflow

        System.out.println(myStack.isEmpty());   // false

        System.out.println(myStack);

    }
    
}
