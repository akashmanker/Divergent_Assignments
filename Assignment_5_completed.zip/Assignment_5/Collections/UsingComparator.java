package Collections;
import java.util.*;


class Student {

    int rollNo;
    String name;
    int age;

    public Student(int rollNo, String name, int age) {
        this.rollNo = rollNo;
        this.name = name;
        this.age = age;
    }

    public void setRollNo(int rollNo) {
        this.rollNo = rollNo;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public int getRollNo() {
        return rollNo;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    @Override
    public String toString() {
        return "Student [rollNo=" + rollNo + ", name=" + name + ", age=" + age + "]";
    }
    
    
    

}
public class UsingComparator {


    public static void main(String[] args) {

        List<Student> list = new ArrayList<>();
        list.add(new Student(103, "Akash", 20));
        list.add(new Student(101, "amit", 39));
        list.add(new Student(112, "rajat", 48));
        list.add(new Student(109, "pavan", 52));
        list.add(new Student(123, "ramesh", 15));
        list.add(new Student(111, "shubham", 17));


        
        // sorting the students based on their age
        // System.out.println("Before sorting ");
        // list.forEach(e -> System.out.println(e));
        

        // Comparator<Student> comparator = (Student s1 , Student s2 ) -> {
        //     if(s1.getAge() > s2.getAge()){  return 1; }
        //     else return -1;
        // };
        
        // Collections.sort(list,comparator);

        // System.out.println("Before sorting ");
        // list.forEach(e -> System.out.println(e));



      //  sorting the students based on their rollNo's;

        System.out.println("Before sorting ");
        list.forEach(e -> System.out.println(e));

        Comparator<Student> comparator = (Student s1 , Student s2) -> {

            if(s1.getRollNo() > s2.getRollNo()){
                return 1;
            }
            else{
                return -1;
            }
        };

        Collections.sort(list,comparator);
        System.out.println("after sorting ");
        list.forEach(e -> System.out.println(e));


        
    }
}

