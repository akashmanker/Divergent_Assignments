package Collections;

import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;

public class Lists {

    public static void main(String[] args) {

        ArrayList<Integer> list1 = new ArrayList<>();
        list1.add(7);
        list1.add(8);
        list1.add(2);
        list1.add(8);
        list1.add(7);
        list1.add(0);

        System.out.println(list1);     // [7, 8, 2, 8, 7, 0]

        LinkedList<Integer> list2 = new LinkedList<>();
        list2.add(7);
        list2.add(8);
        list2.add(2);
        list2.add(8);
        list2.add(7);
        list2.add(0);
        System.out.println(list2);      // [7, 8, 2, 8, 7, 0]
       
       
       
        Vector<Integer> list3 = new Vector<>();
        list3.add(7);
        list3.add(8);
        list3.add(2);
        list3.add(8);
        list3.add(7);
        list3.add(0);
        System.out.println(list3);      // [7, 8, 2, 8, 7, 0]
    }
}
