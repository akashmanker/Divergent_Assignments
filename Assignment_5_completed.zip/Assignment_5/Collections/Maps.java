package Collections;

import java.util.*;

public class Maps {
    public static void main(String[] args) {

        HashMap<Integer, String> hm1 = new HashMap<>();
        hm1.put(7, "amit");
        hm1.put(8, "mohit");
        hm1.put(1, "raj");
        hm1.put(5, "pavavn");
        hm1.put(3, "suraj");

        System.out.println(hm1); // {1=raj, 3=suraj, 5=pavavn, 7=amit, 8=mohit}

        TreeMap<Integer, String> hm2 = new TreeMap<>();
        hm2.put(7, "amit");
        hm2.put(8, "mohit");
        hm2.put(1, "raj");
        hm2.put(5, "pavavn");
        hm2.put(3, "suraj");

        System.out.println(hm2); // {1=raj, 3=suraj, 5=pavavn, 7=amit, 8=mohit}

        LinkedHashMap<Integer, String> hm3 = new LinkedHashMap<>();
        hm3.put(7, "amit");
        hm3.put(8, "mohit");
        hm3.put(1, "raj");
        hm3.put(5, "pavavn");
        hm3.put(3, "suraj");

        System.out.println(hm3); // {7=amit, 8=mohit, 1=raj, 5=pavavn, 3=suraj}

        IdentityHashMap<Integer, String> hm4 = new IdentityHashMap<>();
        hm4.put(7, "amit");
        hm4.put(8, "mohit");
        hm4.put(1, "raj");
        hm4.put(5, "pavavn");
        hm4.put(3, "suraj");

        System.out.println(hm4); // {7=amit, 3=suraj, 8=mohit, 1=raj, 5=pavavn}

        Hashtable<Integer, String> hm5 = new Hashtable<>();
        hm5.put(7, "amit");
        hm5.put(8, "mohit");
        hm5.put(1, "raj");
        hm5.put(5, "pavavn");
        hm5.put(3, "suraj");

        System.out.println(hm5); // Output will be similar to: {5=pavavn, 1=raj, 8=mohit, 3=suraj, 7=amit}

    }

}
