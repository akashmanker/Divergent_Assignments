package Collections;
import java.util.*;

public class Sets {
    public static void main(String[] args){

        Set<Integer> set1 = new HashSet<>();
        set1.add(7);
        set1.add(8);
        set1.add(2);
        set1.add(8);  
        set1.add(7);  
        set1.add(0);

        System.out.println(set1);  // [0, 2, 7, 8]  (order is not guaranteed)

        
        LinkedHashSet<Integer> set2 = new LinkedHashSet<>();
        set2.add(7);
        set2.add(8);
        set2.add(2);
        set2.add(8);  // Duplicate, will be ignored
        set2.add(7);  // Duplicate, will be ignored
        set2.add(0);
        System.out.println(set2);  // [7, 8, 2, 0] (insertion order maintained)

        
        enum weekDays {
            SUNDAY, MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY
        }
        EnumSet<weekDays> eSet1 = EnumSet.allOf(weekDays.class);
        System.out.println(eSet1);  // [SUNDAY, MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY]

        EnumSet<weekDays> eSet2 = EnumSet.noneOf(weekDays.class);
        System.out.println(eSet2);  // []

        EnumSet<weekDays> workday = EnumSet.range(weekDays.MONDAY, weekDays.FRIDAY);
        System.out.println(workday);  // [MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY]
    }
}
