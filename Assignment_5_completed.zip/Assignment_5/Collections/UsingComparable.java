package Collections;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;



class Student implements Comparable<Student> {

    int rollNo;
    String name;
    int age;

    public Student(int rollNo, String name, int age) {
        this.rollNo = rollNo;
        this.name = name;
        this.age = age;
    }

    public void setRollNo(int rollNo) {
        this.rollNo = rollNo;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public int getRollNo() {
        return rollNo;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

   

    @Override
    public int compareTo(Student o1) {

        return (this.rollNo > o1.rollNo) ? 1 : (this.rollNo < o1.rollNo) ? -1 : 0;

        // if(this.rollNo > o1.rollNo){
        //     return 1;
        // }
        // else if(this.rollNo < o1.rollNo){
        //     return -1;
        // }
        // else{
        //     return 0;
        // }
    }
    

    @Override
    public String toString() {
        return "Student [rollNo=" + rollNo + ", name=" + name + ", age=" + age + "]";
    }


}



public class UsingComparable {

  
    
    public static void main(String[] args) {

        List<Student> list = new ArrayList<>();
        list.add(new Student(103, "Akash", 20));
        list.add(new Student(101, "amit", 39));
        list.add(new Student(112, "rajat", 48));
        list.add(new Student(109, "pavan", 52));
        list.add(new Student(123, "ramesh", 15));
        list.add(new Student(111, "shubham", 17));


        System.out.println("before sorting the object");
        list.forEach(e -> System.out.println(e));


        Collections.sort(list);
        
        
        System.out.println("After sorting the object");
        list.forEach(e -> System.out.println(e));

        
    }
}

