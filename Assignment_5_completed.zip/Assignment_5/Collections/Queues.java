package Collections;
import java.util.ArrayDeque;
import java.util.PriorityQueue;
import java.util.Queue;


public class Queues {
    public static void main(String[] args) {
       
        Queue<Integer> queue1 = new ArrayDeque<>();
        queue1.add(7);
        queue1.add(8);
        queue1.add(2);
        queue1.add(8);
        queue1.add(7);
        queue1.add(0);

        System.out.println(queue1);    // [7, 8, 2, 8, 7, 0]
        
        PriorityQueue<Integer> queue2 = new PriorityQueue<>();
        queue2.add(7);
        queue2.add(8);
        queue2.add(2);
        queue2.add(8);
        queue2.add(7);
        queue2.add(0);

        System.out.println(queue2);    // [0, 7, 2, 8, 8, 7]
    }
}
