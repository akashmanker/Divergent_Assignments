package Lamdas;

import java.util.*;
import java.util.Map.Entry;
import java.util.function.BiConsumer;
import java.util.function.BinaryOperator;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;

 class Employee {

    int id;
    String name;
    int age;
    int salary;
    char gender;
    String city;

    public Employee(int id, String name, int age, int salary, char gender, String city) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.salary = salary;
        this.gender = gender;
        this.city = city;
    }

    public int id() {
        return id;
    }

    public String name() {
        return name;
    }

    public int age() {
        return age;
    }

    public int salary() {
        return salary;
    }

    public char gender() {
        return gender;
    }

    public String city() {
        return city;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setSalary(int salary) {
        this.salary = salary;
    }

    public void setGender(char gender) {
        this.gender = gender;
    }

    @Override
    public String toString() {
        return "Employee [id=" + id + ", name=" + name + ", age=" + age + ", salary=" + salary + ", gender=" + gender
                + ", city=" + city + "]";
    }


}

   
public class Filter {
    
    
    public static void main(String[] args) {

        List<Employee> employeeList = new ArrayList<>();

        // Adding 10 Employee objects to the list using the constructor
        employeeList.add(new Employee(1, "Akash", 25, 50000, 'M', "Delhi"));
        employeeList.add(new Employee(2, "Gautam", 28, 60000, 'M', "Mumbai"));
        employeeList.add(new Employee(3, "Sahil", 26, 55000, 'M', "Bangalore"));
        employeeList.add(new Employee(4, "Priya", 24, 48000, 'F', "Chennai"));
        employeeList.add(new Employee(5, "Nisha", 29, 62000, 'F', "Pune"));
        employeeList.add(new Employee(6, "Rohit", 30, 65000, 'M', "Hyderabad"));
        employeeList.add(new Employee(7, "Kavita", 27, 53000, 'F', "Kolkata"));
        employeeList.add(new Employee(8, "Amit", 31, 68000, 'M', "Jaipur"));
        employeeList.add(new Employee(9, "Shreya", 23, 47000, 'F', "Ahmedabad"));
        employeeList.add(new Employee(10, "Vikas", 32, 70000, 'M', "Surat"));


        Stream<Employee> stream = employeeList.stream();

        // filter method 
        Predicate<Employee> p1 = new Predicate<Employee>() {

            @Override
            public boolean test(Employee t) {
                 if(t.salary() < 50000){
                    return true;
                 }
                 else return false;
            }
            
        };

       List<Employee> filtered =  stream.filter(e -> e.salary()>50000).collect(Collectors.toList());
       System.out.println(filtered);

    }

}
