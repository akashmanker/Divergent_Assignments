package Lamdas;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.*;
public class Consumer_Function {
    
    public static void main(String[] args) {
        
       Consumer<String> str = e -> System.out.println("Data is "+e);
       str.accept("Hello this is akash");


       List<String> strList = new ArrayList<>(List.of("akash","atulh","pavan","prabhat"));
       List<Integer> integerStream = strList.stream().map(e -> e.length()).toList();
       System.out.println(integerStream);
       Function<Double,Integer> func =  d -> d.intValue();

    }
}
