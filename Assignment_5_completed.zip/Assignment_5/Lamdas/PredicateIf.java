package Lamdas;

import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.*;

public class PredicateIf {

    public static void main(String[] args) {

       Predicate<Integer> p = (num) ->  num % 2 == 0;
      
       List<Integer> list = Arrays.asList(1 , 2, 3 ,4 ,5 ,6 ,7 ,8);
       
       System.out.println(list);
       
       list = list.stream().filter(p).collect(Collectors.toList());
       
       System.out.println(list);

       
    }
}