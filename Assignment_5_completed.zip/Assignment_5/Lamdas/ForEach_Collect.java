package Lamdas;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.Map.Entry;
import java.util.Map;
import java.util.stream.Collectors;

class Employee {

    int id;
    String name;
    int age;
    int salary;
    char gender;
    String city;

    public Employee(int id, String name, int age, int salary, char gender, String city) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.salary = salary;
        this.gender = gender;
        this.city = city;
    }

    public int id() {
        return id;
    }

    public String name() {
        return name;
    }

    public int age() {
        return age;
    }

    public int salary() {
        return salary;
    }

    public char gender() {
        return gender;
    }

    public String city() {
        return city;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setSalary(int salary) {
        this.salary = salary;
    }

    public void setGender(char gender) {
        this.gender = gender;
    }

    @Override
    public String toString() {
        return "Employee [id=" + id + ", name=" + name + ", age=" + age + ", salary=" + salary + ", gender=" + gender
                + ", city=" + city + "]";
    }

}

public class ForEach_Collect {

    public static void main(String[] args) {
        List<Employee> employeeList = new ArrayList<>();

        employeeList.add(new Employee(1, "Akash", 25, 50000, 'M', "Delhi"));
        employeeList.add(new Employee(2, "Gautam", 28, 60000, 'M', "Mumbai"));
        employeeList.add(new Employee(3, "Sahil", 26, 55000, 'M', "Bangalore"));
        employeeList.add(new Employee(4, "Priya", 24, 48000, 'F', "Chennai"));
        employeeList.add(new Employee(5, "Nisha", 29, 62000, 'F', "Pune"));
        employeeList.add(new Employee(6, "Rohit", 30, 65000, 'M', "Hyderabad"));
        employeeList.add(new Employee(7, "Kavita", 27, 53000, 'F', "Kolkata"));
        employeeList.add(new Employee(8, "Amit", 31, 68000, 'M', "Jaipur"));
        employeeList.add(new Employee(9, "Shreya", 23, 47000, 'F', "Ahmedabad"));
        employeeList.add(new Employee(10, "Vikas", 32, 70000, 'M', "Surat"));

        employeeList.stream().forEach(e -> {
            e.setAge(0);
        });

        // collect method

        Set<Employee> collect = employeeList.stream().filter(e -> e.gender ==
        'M').collect(Collectors.toSet());
        System.out.println(collect);

        employeeList.stream().filter(e -> e.gender ==
        'M').collect(Collectors.toSet());
        System.out.println(collect);

        Map<String, String> collect2 = employeeList.stream().filter(e -> e.age > 18)
                .collect(Collectors.toMap(Employee::city, Employee::name));

        for(Entry<String, String> enSet : collect2.entrySet()){
        System.out.println(enSet.getKey()+" = "+enSet.getValue());
        }

        collect2.forEach((e,i) -> System.out.println(e + "==" + i));
    }

}
