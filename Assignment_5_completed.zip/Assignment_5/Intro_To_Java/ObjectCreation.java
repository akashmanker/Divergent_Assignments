package Intro_To_Java;
public class ObjectCreation {

    int a = 10;
    String name = "Akash";

    public static void main(String[] args) {
        
        ObjectCreation obj1 = new ObjectCreation();
        ObjectCreation obj2 = new ObjectCreation();

        System.out.println(obj1.a +" "+obj1.name);
        
        System.out.println(obj2.a +" "+obj2.name);



    }
    
}