package Intro_To_Java;
public class DataTypes {
        public static void main(String[] args) {
            byte a;
            short b ;
            int c ;
            long d ;
            float e ;
            double f;
            String g ;
            char h ;
            
        }
}
