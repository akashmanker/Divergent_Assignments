package Intro_To_Java;
public class Comments {

    public static void main(String[] args) {
        
        // This is single lined comment

        /*
         * 
         * This is a
         * multilined comment 
         * 
         * 
         */
    }
    
}
