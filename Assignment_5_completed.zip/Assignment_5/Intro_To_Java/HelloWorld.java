package Intro_To_Java;

public class HelloWorld {

        public static void main(String agr[]){
        
            System.out.println("Hello there i am akash");
        }
        
    
}