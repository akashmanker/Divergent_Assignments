package Intro_To_Java;
public class ArrayDeclaration {
    
        public static void main(String[] args) {
       
            // array can be declared as 
          int []a = {1,2,3,4};
    
          int b[] = {1,2,3,4};       
         
          int[] c= {1,2,3,4};       
          
          for(int n: a){
            System.out.print(n +" ");
          }
          System.out.println();
        
        
          for(int n: b){
            System.out.print(n +" ");
          }
          System.out.println();
        

          for(int n: c){
            System.out.print(n +" ");
          }
          System.out.println();

        }
    }

