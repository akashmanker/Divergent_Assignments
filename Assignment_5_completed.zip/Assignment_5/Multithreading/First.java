package Multithreading;
    
    public class First extends Thread {

        public   void run() {
            System.out.println(Thread.currentThread().getName() +"running run method");
        }
    
        public static void main(String[] args) {
    
            First t1 = new First();
            First t2 = new First();
            First t3 = new First();
            
            t1.setName("t1");
            t2.setName("t2");
            t3.setName("t3");

            State state = t2.getState();
            System.out.println(state);
   
    
            t1.start();
            t2.start();
            t3.start();
            System.out.println(t2.getState());
    
    
        }
    
    }

