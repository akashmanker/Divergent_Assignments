package Multithreading;

public class Second {

    public static void main(String[] args) {

        Runnable r = () -> { for(int i=0; i<5; i++){System.out.println(Thread.currentThread().getName()+" executed on high priority");} };
        Thread t1 = new Thread(r);
        Thread t2 = new Thread(r);
        t1.setPriority(Thread.MAX_PRIORITY);
        t2.setPriority(Thread.NORM_PRIORITY);
        
        t1.start();
        t2.start();
}
        
}

