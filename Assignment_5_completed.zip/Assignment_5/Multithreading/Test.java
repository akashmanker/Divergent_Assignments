package Multithreading;

public class Test  extends Thread{

    
    @Override
    public void run() {

        System.out.println("This is run method running of Thread class");

    }
    
    public static void main(String[] args) {
        ThreadUsingClass t = new ThreadUsingClass();

        t.run();
    }
}
