package Exceptions;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Logging {

    public static void main(String akash[]) {

        Logger logger = Logger.getLogger("Logging");

        
        logger.log(Level.WARNING,"Last Warning");
        logger.log(Level.INFO,"Last Warning");
      
 
}
}
