package Exceptions;

 class MyException extends Exception {

    public MyException(String message){
        super(message);
    }

    
}


public class CreatingCustomException {


    public void ageChecker(int age) throws MyException{

        if(age<18){
            throw new MyException("You are not eligible to drive");
        }
        else{
            System.out.println("YOu can drive");
        }


    }
    
    public static void main(String[] args) {

        int age = 1;
        CreatingCustomException obj = new CreatingCustomException();

        try {

            obj.ageChecker(age);
        } 
        catch (MyException e) {
            
            System.out.println("Exception comed");
            System.out.println(e.getMessage());
        }

    }

}
