package Exceptions;

public class ThrowingException {


    public static void divide(int n){    // throws keyword is not necessay in new versions

        try {

            int result =  n/0;

        } 
        catch (ArithmeticException e) {
            throw e;
        }
    }

    
    public static void main(String[] args) {

        try{
        
            divide(7);          //exception object will came here
        }
        catch(ArithmeticException e){
            System.out.println("Exception occured in our program");
            System.out.println("cause : "+e.getMessage());
        }
    
        }   


}
