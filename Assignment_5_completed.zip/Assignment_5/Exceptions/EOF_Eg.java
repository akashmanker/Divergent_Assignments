package Exceptions;

import java.io.EOFException;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;


public class EOF_Eg {

    public static void readFile(Scanner is,int expectedLen) throws EOFException{

        int readedLen = 0;
        String line = "";
        while (is.hasNext()) {
             line = is.nextLine();
             readedLen += line.length();
             System.out.println(line);

             if(readedLen >= expectedLen){
                break;
             }
        }

        if(readedLen < expectedLen ){
            throw new EOFException();
        }
    }

    public static void main(String argg[]){

        File file = new File("Exceptions/file.txt");

        try {
            Scanner sc = new Scanner(file);
            readFile(sc,50);
            System.out.println("File readed successfully");

        } catch (EOFException e) {
            System.out.println("OOps file is not have expected length");
            e.printStackTrace();
        }
        catch(FileNotFoundException e){
            e.printStackTrace();
        }
    }
}

