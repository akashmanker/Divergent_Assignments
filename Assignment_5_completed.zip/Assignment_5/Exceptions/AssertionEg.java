package Exceptions;

public class AssertionEg {
    
    public static void main(String[] args) {
       
        int value = -5;

        assert value >= 0 : "The value is negative: " + value;

        System.out.println("The value is: " + value);
    }
}


