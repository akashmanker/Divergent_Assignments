import java.util.Scanner;

public class Prob_2 {
  
    // Write a program to print the Fibonacci series up to n terms using recursion and iteration
  
  
  
    public static int printUsingRecursion(int n){

        if(n <= 1){
            return n;
        }

        return printUsingRecursion(n-1) + printUsingRecursion(n-2);
    }  
       



    public static void printUsingIteration(int n){

        System.out.println("Printing using iteration");
        int a = 0;
        int b = 1;
        int c = 0;

        for(int i=0;i<n;i++){
            System.out.print(a+" ");
            c = a+b;
            b = a;
            a = c;

        }
        
    }

    

    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the Number to Print the fibonaaci");
        int n = sc.nextInt();
        // printUsingIteration(n);

        for(int i=0;i<n;i++){
            System.out.print(printUsingRecursion(i)+" ");
        }
    }

}
