import java.util.*;

public  class Prob_9 {
    
    // 9	Write a program using Java 8's lambda expressions to filter and print all even numbers from a list of integers.
    
    public static void main(String[] args) {
        
        List<Integer> list = new ArrayList<>(List.of(1,2,3,4,5,6,7,8,9,10,20));

        List<Integer> evenList = list.stream().filter(f -> f % 2 == 0).toList();

        System.out.println(evenList);




    }
}
