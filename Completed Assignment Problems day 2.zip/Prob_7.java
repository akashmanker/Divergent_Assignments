// Solve the Producer-Consumer problem using Java's wait() and notify() methods

class Box {

    int data;
    int i = 0;
    boolean flag = false;

    synchronized public void put() throws InterruptedException{
       
        while (true) {

            if(flag == false){
                data = i;
                System.out.println(Thread.currentThread().getName()+" putted "+data+" in box");
                Thread.sleep(1000);
                notifyAll();
                flag = true;
                i++;
            }
            else{
                wait();
            }
        }

    }

    synchronized public void get() throws InterruptedException{

        while (true) {

            if(flag){
                System.out.println(Thread.currentThread().getName()+" got "+data+" from box");
                Thread.sleep(1000);
                flag = false;
                notifyAll();
            }
            else{
                wait();
            }
        }

    }

}

class Producer implements Runnable {

    Box box;

    public Producer(Box box) {
        this.box = box;
        Thread t1 = new Thread(this,"Producer");
        t1.start();
    }

    @Override
    public void run() {

        try {
            box.put();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

}

class Consumer implements Runnable {
    Box box;

    
    public Consumer(Box box) {
        this.box = box;
        Thread t1 = new Thread(this,"Consumer");
        t1.start();

    }


    @Override
    public void run() {
        try {
            box.get();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }

}

public class Prob_7 {

    public static void main(String[] args) {

        Box box = new Box();
        Producer producer = new Producer(box);
        Consumer consumer = new Consumer(box);
    }
}
