import java.io.*;
import java.util.*;

public class Prob_4 {

   // Write a program to read a text file and count the occurrences of each word. Display the words and their counts.

    public static void main(String[] args){

        try{
         File file = new File("Test.txt");

        file.createNewFile();
        
        FileReader fr = new FileReader(file);

        BufferedReader br = new BufferedReader(fr);
        
        String line = br.readLine();

        Map<String,Integer> map = new HashMap<>();
         
         while(line != null)
        {   
            String str[] = line.split(" ");
            
            for(String e : str){
                map.put(e, map.getOrDefault(e, 0)+1);
            }

            line = br.readLine();
        }

        System.out.println("Count of each word in the file is");
        for(Map.Entry<String,Integer> entry : map.entrySet()){
            System.out.println(entry.getKey()+" = "+entry.getValue());
        }
        }
        catch(Exception e){
            e.printStackTrace();
        }

    }
}