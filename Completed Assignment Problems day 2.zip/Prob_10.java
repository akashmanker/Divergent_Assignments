import java.util.*;
import java.util.stream.Collectors;

//Write a program to:
// Group a list of Employee objects by department.
// Count the number of employees in each department using Streams.
// The Employee class should have fields: id, name, age, and department.

class Employee {

    public int id;
    public String name;
    public String department;

    public Employee(int id, String name, String department) {
        this.id = id;
        this.name = name;
        this.department = department;
    }


    public int getId() {
        return id;
    }
    public String getName() {
        return name;
    }
    public String getDepartment() {
        return department;
    }
    public void setId(int id) {
        this.id = id;
    }
    public void setName(String name) {
        this.name = name;
    }
    public void setDepartment(String department) {
        this.department = department;
    }
     
}

public class Prob_10 {

    private static Map<String, List<Employee>> collect;

    public static void main(String[] args) {

        List<Employee> list = new ArrayList<>();

        list.add(new Employee(100, "Rajat", "Hr"));
        list.add(new Employee(101, "Prakash", "marketing"));
        list.add(new Employee(102, "amit", "business"));
        list.add(new Employee(103, "sujal", "Hr"));
        list.add(new Employee(104, "rahul", "marketing"));
        list.add(new Employee(105, "pavan", "bussiness"));
        list.add(new Employee(106, "amit", "admin"));
       
        // grouping the departments
        // Map<String,List<Employee>> map = new HashMap<>();


        Map<String,List<Employee>> map  = list.stream()
        .collect(Collectors.groupingBy(Employee :: getDepartment));

        for(Map.Entry<String,List<Employee>> entry : map.entrySet()){
            System.out.println("Department : "+entry.getKey()+" || Employees : "+entry.getValue().size());
        }

    }
}