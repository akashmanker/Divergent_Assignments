public class Prob_3 {
    
// Write a program to sort an array of integers without using any built-in sorting methods.


        public static int partition(int arr[],int low , int high){

            int i=low;
            int pivot = low;
            int j = high;

            while (i < j) {
                
                while (arr[i] <= pivot && i<high) {
                    i++;
                }

                while (arr[j] > pivot && j>low) {
                    j--;
                }

                if(i < j){
                    int temp = arr[i];
                    arr[i] = arr[j];
                    arr[j] = temp;
                }
            }   

            int temp = arr[j];
            arr[j] = arr[low];
            arr[low] = temp;

            return j;
        }

        public static void QuickSort(int arr[], int low , int high){

            if(low < high){

                int positionIdx = partition(arr,low,high);

                QuickSort(arr,low,positionIdx-1);
                QuickSort(arr,positionIdx+1,high);

            }


        }
        public static void main(String[] args) {
            int arr[] = {5,4,3,2,1,0};

            QuickSort(arr , 0 , arr.length-1);

            for(int e : arr){
                System.out.print(e+" ");
            }

        }

}
