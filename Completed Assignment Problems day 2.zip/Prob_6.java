
//Write a program to demonstrate multithreading by creating a class that extends Thread and another that implements Runnable. Show how multiple threads can run simultaneously.

class ThreadEg1 extends Thread{

	public String msg;
	ThreadEg1(String msg){
		this.msg = msg;
	}

	public void run() {
		try
		{
		for(int i=0;i<5;i++){
		System.out.println(msg);
		Thread.sleep(1000);
		}
		}catch(Exception e){
			System.out.println(e);
		}
}



}

class ThreadEg2 implements Runnable{

	public String msg;
	ThreadEg2(String msg){
		this.msg = msg;
	}

	@Override
	public void run() {
		try
		{
		for(int i=0;i<5;i++){
		System.out.println(msg);
		Thread.sleep(1000);
		}
		}catch(Exception e){
			System.out.println(e);
		}	
	}



}



public class Prob_6{

public static void main(String args[]){
 
ThreadEg1 t1 = new ThreadEg1("Thread1 using Thread class");
ThreadEg1 t2 = new ThreadEg1("Thread2 using Thread class");
t1.start();
t2.start();


ThreadEg2 m1 = new ThreadEg2("Thread1 using Runnable interface");
Thread k1 = new Thread(m1);
k1.start();

ThreadEg2 m2 = new ThreadEg2("Thread2 using Runnable interface");
Thread k2 = new Thread(m2);
k2.start();	


}

}