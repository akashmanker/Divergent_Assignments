 // Create a custom exception called InvalidAgeException and write a program to demonstrate its usage by checking if a user-provided age is valid (age >= 18).

import java.util.Scanner;

class InvalidAgeException extends Exception {

    InvalidAgeException(String str){
        super(str);
    }
}



public class Prob_5 {


    public static void ageVerifier(int age)throws InvalidAgeException{

        if(age < 18){
            System.out.println("Sorry you are not eligible to drive the vehicle");
            throw new InvalidAgeException("Age is not Valid for Driving");
        }
        else{
            System.out.println("You can drive the vehicle");
        }
    }
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);  
        System.out.println("Enter your age to verify");
        int age = sc.nextInt();
    
        try{
            ageVerifier(age);
        }
        catch(InvalidAgeException e){
            System.out.println(e);
        }



    }
}
