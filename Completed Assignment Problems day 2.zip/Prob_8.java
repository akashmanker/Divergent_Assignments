
// Create a Singleton class in Java and ensure i is thread-safe. Explain its usage in a multithreaded environment.

 class MySingleton {

    public String creatorName = "Akash";

    static private  MySingleton ref;

    private MySingleton(){
    }
    
     synchronized public static  MySingleton getMyObject(){

        if(ref == null){
            ref = new MySingleton();
        }

        return ref;
    }
}



class SingletonCheck implements Runnable {

    @Override
    public void run() {
        
        MySingleton obj = MySingleton.getMyObject();
        System.out.println("Thread name ="+ Thread.currentThread().getName()+" Created obj = "+obj.hashCode() +" property = "+obj.creatorName);
    
    }



}

public class Prob_8 {

public static void main(String[] args) {
  
    Thread t1 = new Thread(new SingletonCheck(),"Threed 1");
    Thread t2 = new Thread(new SingletonCheck(),"Threed 2");
    Thread t3 = new Thread(new SingletonCheck(),"Threed 3");

    t1.start();
    t2.start();
    t3.start();


   

}

}
