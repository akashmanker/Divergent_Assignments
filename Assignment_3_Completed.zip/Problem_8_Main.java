import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

//3	Write a program that uses a custom class loader to load classes //dynamically. Debug issues when the class loader is not releasing memory. *

class CustomClassLoader extends ClassLoader {
    private String classesDir;  

    public CustomClassLoader(String classesDir) {
        this.classesDir = classesDir;
    }

    @Override
    protected Class<?> findClass(String name) throws ClassNotFoundException {
        try {
            String fileName = name.replace('.', '/') + ".class";
            byte[] classData = Files.readAllBytes(Paths.get(classesDir + fileName));

            return defineClass(name, classData, 0, classData.length);
        } catch (IOException e) {
            throw new ClassNotFoundException("Could not load class " + name, e);
        }
    }
}

public class Problem_8_Main {
    public static void main(String[] args) throws  Exception{
        String classDir = "C:\\Users\\CWB_BETUL\\Desktop\\Divergent\\Assignment_3\\classes\\";

        CustomClassLoader customClassLoader = new CustomClassLoader(classDir);

        try {
            Class<?> loadedClass = customClassLoader.loadClass("MyClass");
            Object instance = loadedClass.getDeclaredConstructor().newInstance();

            System.out.println("Class loaded: " + loadedClass.getName());

            Thread.sleep(5000);
            loadedClass = null;
            instance = null;
            customClassLoader = null;

            System.gc();

            System.out.println("Custom class loader and classes are cleared.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
