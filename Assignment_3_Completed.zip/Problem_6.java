
public class Problem_6 {

    ///	Create a program that starts multiple threads but doesn’t terminate them correctly. Debug thread leaks and observe their impact on memory.

        public static void main(String[] args) {
            System.out.println("Starting thread");

            for (int i = 0; i < 100; i++) {
                Thread t = new Thread(() -> {
                    try {
                        while (true) {
                            Thread.sleep(1000);

                            System.out.println("Hello sirji");
                            System.out.println(Thread.currentThread().getName());
                        }
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                });
                t.start();
            }

            System.out.println("Threads started");
        }
    }


