


//Write a program with objects that reference each other in a circular manner. Observe and debug if the garbage collector can clean them up.


class First{

    Second obj;

    @Override
    public void finalize() throws Throwable {
        System.out.println("Gc Destoring the obj of second");
    }

}

class Second{

    First obj;

    public void finalize() throws  Throwable{
        System.out.println("Gc destroying obj 0f first");
    }

}


public class Problem_5 {

    public static  void main(String arg[]){

        First a = new First();
        Second s = new Second();

        a.obj = s;
        s.obj = a;

        a = null;
        s = null;


        System.gc();
    }

}
