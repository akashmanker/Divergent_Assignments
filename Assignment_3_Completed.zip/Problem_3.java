public class Problem_3 {

    public static  void method(){

        method();

    }

//    Write a program with infinite recursion to trigger a StackOverflowError. Debug the stack trace to identify the root cause.


    public static  void  main(String args[]){

        System.out.println("Creating stack overflow conditon");


            method();

      
    }
}
