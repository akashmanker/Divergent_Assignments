
//    7	Create a cache that never removes expired objects. Debug and improve the design using WeakHashMap or similar structures.

import java.util.HashMap;
import java.util.Map;
import java.util.WeakHashMap;

    public class Problem_7 {

        private static final WeakHashMap<String, String> cache = new WeakHashMap<>();
        private static final Map<String, String>  mapCache = new HashMap<>();

        public static void main(String[] args) throws InterruptedException {

            System.out.println("Starting cache with HashMap and is static due which it relies in memmory until the program life ");

            for (int i = 0; i < 1000; i++) {
                mapCache.put("Key" + i, "Value" + i);
                System.out.println("Added Key" + i);
                Thread.sleep(50);
            }

            System.out.println("Final Cache size: " + mapCache.size());


//    solve usign weakhashmap
//            System.out.println("Starting cache with WeakHashMap an its object will automatically collected by gc if no longer in use ");
//
//            for (int i = 0; i < 500; i++) {
//                cache.put(new String("Key" + i), "Value" + i);
//                System.out.println("Added Key -> " + i);
//                Thread.sleep(50);
//
//                if (i % 100 == 0) {
//                    System.out.println("Cache size: " + cache.size());
//                }
//            }
//
//            System.out.println("WeakHashMap example completed. \n");
        }
    }

