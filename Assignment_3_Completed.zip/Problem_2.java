import java.util.ArrayList;
import java.util.List;

public class Problem_2 {


   /// Create a program that allocates large arrays in a loop to observe heap utilization. Use tools like jvisualvm or jconsole to monitor memory usage.
    public static  void main(String args[]) throws InterruptedException {

        List<int[]> list = new ArrayList<>();

        int size = 100;
        int arr[] = new int[size];
        list.add(arr);


            System.out.println("wating 9 sec to start");
            Thread.sleep(9000);

             System.out.println("process starting");
             for(int i=0;i<50;i++){

            list.add(new int [arr.length * 1234]);
            System.out.println("Array allocated of size "+list.getLast().length);



                Thread.sleep(1000);

        }

        System.out.println("process ended successfully");

    }
}
