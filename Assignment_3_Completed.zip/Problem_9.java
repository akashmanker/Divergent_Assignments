import java.util.ArrayList;

import  java.util.*;
public class Problem_9 {

//  9	Create a program that unnecessarily creates duplicate objects (e.g., using new repeatedly instead of caching values). Debug heap usage and optimize memory management.

    public static void main(String[] args) throws InterruptedException {
        List<String> str = new ArrayList<>();

        for(int i=0;i<100000;i++){
            Thread.sleep(59);
            str.add( new String("AkashMankerJIi"));
            System.out.println("created");
        }

    }
}
