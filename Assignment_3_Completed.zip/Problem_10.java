import java.util.ArrayList;
import java.util.*;

public class Problem_10 {

    // 10 Write a program to deliberately cause an OutOfMemoryError by creating many
    // objects in a loop. Debug using a heap dump to find out where memory is being
    // consumed.

    public static void main(String[] args) throws InterruptedException {
        
            List<String> list = new ArrayList<>();

            try {
                while (true){
                    list.add(new String("akashmankerfromdewasiiiiiiiiiiiiiiiiiinggggggggggglakgajajwlfajwjwjf"));
                }
            }
            catch (Error e) {
                e.printStackTrace();
            }

    }
}
