import java.util.ArrayList;
import java.util.List;

public class Problem_1 {

  //  Write a program that unintentionally creates a memory leak (e.g., by keeping references in a static collection). Debug and resolve the issue.


    static List<Object> list = new ArrayList<>();

    public static  void main(String args[]){


        for (int i = 0; i < 100000; i++) {
           list.add((Object) new Object());
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }

//        this is will create a extensive memmory leak because object in the list will not cleared by gc
//        because the list is declared as a static (means list class ke saath hi associated hai object ke saath nhi ,means vo application ke lifetime tak present rahegi
//        aur garbage collector bhi uski memmory release nhi karega;
//        )
//        means it will remain in the Memmory jab tak ki class loaded hai

//        resoultion -> we should not use static list util and unless we need
//                        if we are using it we must clear() it in order to free up memory


    }

}
