import javax.swing.plaf.TableHeaderUI;

public class Problem_4 {

    // 4	Use string concatenation in a loop without using StringBuilder. Monitor heap usage and debug the excessive memory consumption.

    public static void main(String[] args) {

            String str = "Hello__________";

                System.out.println("staring the concatenation in 9 sec");

                try {
                    Thread.sleep(9000);

                    for(int i=0;i<10000;i++) {

                        str += "Akash_Manker_Dewas_Mp_455001";

                        System.out.println("Current string size = " + str.length());

                        Thread.sleep(1000);
                    }

                }
                catch (Exception e){
                    e.printStackTrace();
                }

    }
}
