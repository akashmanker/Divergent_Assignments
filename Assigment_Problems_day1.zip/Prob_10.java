import java.util.Scanner;

public class Prob_10 {

    public static boolean checkPalindrome(int n){

        int ogNum = n;
        int reverseNum = 0;

        while (n != 0) {
            int digit = n % 10;
            reverseNum = reverseNum * 10 + digit;
            n /= 10;
        }

        return ogNum == reverseNum;
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the num");
        int n = sc.nextInt();
        System.out.println(checkPalindrome(n));
    }
}
