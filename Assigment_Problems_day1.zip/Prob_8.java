import java.util.Scanner;

import javax.swing.text.StyledEditorKit;

public class Prob_8 {

    public static int findLargest(int arr[]){

        if(arr.length == 0){
            System.out.println("Array is empty");
        }

        int min = 0;
        for(int i=0;i<arr.length;i++){
            if(arr[i] > min){
                min = arr[i];
            }
        }

        return min;
    }
    
    public static void main(String[] args) {
         int arr[] = {2,3,56,43,999,3,567,7,644};
         int k = findLargest(arr);
         System.out.println("Largest Number is = "+k);
    }
}
