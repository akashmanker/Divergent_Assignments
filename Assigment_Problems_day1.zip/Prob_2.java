import java.util.Scanner;


public class Prob_2 {

        public static int factorialRecursion(int n){

            
        if(n <= 1){
            return 1;
        }

        return n * factorialRecursion(n-1);
        }


        public static int factorialLoop(int n){

            int x = 1;
    
            if(n==0) return 1;
    
            for(int i=1;i<=n;i++){
                x = i*x;
            }
    
            return x;
        }


       public static void main(String[] args) {
               Scanner sc = new Scanner(System.in);
                    
               System.out.print("Please enter digit = ");
                     int k = sc.nextInt(); 
                    
                     int ans = factorialLoop(k);
                     System.out.println("Factorial is = "+ans);

       }
}