import java.util.*;
import java.util.Scanner;

public class Prob_9 {

    public static int countVowels(String str){
        List<Character> list = new ArrayList<>(List.of('a','A','e','E','i','I','o','O','u','U'));
        int count = 0;
        for(int i=0;i<str.length();i++){
            if(list.contains(str.charAt(i))){
                count++;
            }
        }
        return count;
    }
    public static void main(String arg[]){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the string");
        String str = sc.nextLine();
        System.out.println("Number of vowels in String are = "+countVowels(str));
    }   
}
