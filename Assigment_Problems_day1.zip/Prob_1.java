import java.util.Scanner;

public class Prob_1 {

     public static boolean service(int v) {
          if (v % 2 == 0) {
               return true;
          } else {
               return false;
          }
     }

     public static void main(String[] args) {
          Scanner sc = new Scanner(System.in);
          System.out.print("Please enter digit");
          int v = sc.nextInt();
          boolean b = service(v);
          if (b == true) {
               System.out.println("it is even");
          } else {
               System.out.println("it is odd");
          }

     }
}