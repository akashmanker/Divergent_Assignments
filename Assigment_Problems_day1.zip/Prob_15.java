// Write a program to demonstrate the following ways to iterate over a List: Using a for loop.

import java.util.ArrayList;
import java.util.List;

public class Prob_15 {
    
    public static void main(String[] args) {
        List<String> list = new ArrayList<>(List.of("Akash","rohan" ,"bharat","pavan","sumit"));
        
        System.out.println("Traversing the list");

        for(String e  : list){
            System.out.println(e);
        }
    }

}
