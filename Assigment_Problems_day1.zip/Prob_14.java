// Write a program to count the frequency of each word in a string using a HashMap.

import java.util.HashMap;
import java.util.Scanner;

public class Prob_14 {
    
    public static void main(String args[]){

        Scanner sc = new Scanner(System.in);
        HashMap<String,Integer> map = new HashMap<>();
        System.out.println("Enter the Sentence");
        String str = sc.nextLine();
        str = str.toLowerCase();

        String arr[] = str.split(" ");

        for(String e  : arr){
            map.put(e, map.getOrDefault(e, 0)+1);
        }
       

        System.out.println("Frequency of Each word in sentence is = "+map);
    }
}
