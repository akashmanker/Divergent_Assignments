import java.util.Scanner;

public class Prob_6 {

    public static int getSumOfDigits(int n){

        int sum = 0;
        
        while (n >= 1) {
            sum += n%10;
            n = n/10;
        }

        return sum;
    }
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the Number");
        int n = sc.nextInt();
        System.out.println("Sum is = "+getSumOfDigits(n));
    }
}
