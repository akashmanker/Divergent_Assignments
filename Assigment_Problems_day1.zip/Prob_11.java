import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

import javax.swing.plaf.synth.SynthPasswordFieldUI;

public class Prob_11 {
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the size of List");
        int n = sc.nextInt();
        List<Integer> list = new ArrayList<>(n);
        System.out.println("Now Enter the digits");
        for(int i=0;i<n;i++){
            int k = sc.nextInt();
            list.add(k);
        }

        System.out.println("Max Element in the list is "+Collections.max(list));
    }
}   
