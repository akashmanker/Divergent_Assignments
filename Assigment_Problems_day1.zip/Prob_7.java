import java.util.Scanner;

public class Prob_7 {

    public static void printTable(int n){

        for(int i=1;i<=10;i++){
            System.out.println(n+" * "+i+" = "+ n*i);
        }
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the Number to Print its Multiplicaton Table");
        int n = sc.nextInt();
        printTable(n);
    }
}
