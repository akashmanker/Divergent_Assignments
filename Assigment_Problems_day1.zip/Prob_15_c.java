import java.util.ArrayList;
import java.util.List;
// Write a program to demonstrate the following ways to iterate over a List: using for each method.


public class Prob_15_c {
    
    public static void main(String[] args) {
        List<String> list = new ArrayList<>(List.of("Akash","rohan" ,"bharat","pavan","sumit"));
        
        System.out.println("Traversing the list");

        list.forEach(e -> System.out.println(e));
        
    }
}
