import java.util.Scanner;

public class Prob_5 {

    public static void swap(int a , int b){
        a = a+b;
        b = a-b;
        a = a-b;
    }
    
    public static void main(String[] args) {
        Scanner sc =  new Scanner(System.in);
        System.out.println("Enter the first Number n1 = ");
        int n1 = sc.nextInt();
        System.out.println("Enter the second Number n2 = ");
        int n2 = sc.nextInt();

        n1 = n1+n2;
        n2 = n1-n2;
        n1 = n1-n2;
        System.out.println("After Swapping Nums are n1 = "+n1+" & n2 = "+n2);
    }

}
