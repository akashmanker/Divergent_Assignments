import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

// Write a program to demonstrate the following ways to iterate over a List: Using an Iterator.

public class Prob_15_b {
    
    public static void main(String[] args) {
        List<String> list = new ArrayList<>(List.of("Akash","rohan" ,"bharat","pavan","sumit"));
        
        System.out.println("Traversing the list using iterator" );

        Iterator iterator = list.listIterator();
        while (iterator.hasNext()) {
            System.out.println(iterator.next());
        }
    }
}
