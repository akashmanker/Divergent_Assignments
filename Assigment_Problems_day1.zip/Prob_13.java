import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

public class Prob_13 {
    public static void main(String[] args) {
        Map<String,Integer> map = new HashMap<>();  
        map.put( "apple" , 3);
        map.put( "mango" ,5); 
        map.put( "banana",2); 
        map.put( "grapes",1); 
        map.put( "pineapple",4);
        
        System.out.println("Original Map is = "+map);

        TreeMap<String,Integer> treeMap = new TreeMap<>(map);
    
        System.out.println("After Sorting using Treemap");

        for(Map.Entry<String,Integer> entry : treeMap.entrySet()){
            System.out.println("key = "+entry.getKey()+" And Value = "+entry.getValue());
        }
 

    }
}
